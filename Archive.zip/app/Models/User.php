<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasFactory, Notifiable;
    protected $table = 'users';

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
        'username',
        'phone',
        'address',
        'profile_image',
    ];
    public function nfts()
    {
        return $this->hasMany(NFT::class);
    }
    public function wallet()
    {
        return $this->hasOne(related: Wallet::class);
    }

    public function hasConnectedWallet(): bool
    {
        return (bool) $this->wallet?->isConnected();
    }

    public function canRequestWithdrawal(): bool
    {
        return $this->hasConnectedWallet() && (bool) $this->wallet?->hasWithdrawalWallet();
    }

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }
}
